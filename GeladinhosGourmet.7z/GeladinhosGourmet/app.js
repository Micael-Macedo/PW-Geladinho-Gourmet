const { response } = require('express');
var express = require('express');
var {engine} = require('express-handlebars')
var bp = require('body-parser')

var app = express();

//configurções para identificar framework que fará rendeirizações
app.engine('handlebars', engine());
app.set('view engine', 'handlebars');
app.set('views', './views');
app.use(bp.urlencoded({extended: false}))
app.use(bp.json());

app.get('/', function (request, response){
    response.render('index');
})

app.get('/cadastro', function(request, response){
    response.render('cadastro');
})
app.post('/cadastro', function(request, response){
    sabor = request.body.sabor;
    peso = request.body.peso;
    preco = request.body.preco;
    console.log("Sabor: " + sabor);
    console.log("Peso: " + peso);
    console.log("Preco: " + preco);
})
app.listen(3000);